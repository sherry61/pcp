placeholder PRE cipher payload for integration testing
